// ticketPanelOpHandlers.js
// Handles the interactive dropdown created by /ticketpanelop.
// Fully additive: reuses the existing ticket data model (saveTicketData /
// getTicketKey) and the existing ticket_claim / ticket_pin / ticket_close
// button handlers so tickets created here work exactly like tickets created
// by /ticket — it does not modify how /ticket itself creates or manages tickets.

import {
  ChannelType,
  PermissionFlagsBits,
  ActionRowBuilder,
  ButtonBuilder,
  ButtonStyle,
  ModalBuilder,
  TextInputBuilder,
  TextInputStyle,
  MessageFlags,
} from 'discord.js';
import { createEmbed, successEmbed } from '../utils/embeds.js';
import { getGuildConfig } from '../services/config/guildConfig.js';
import { getTicketPanelOpData } from '../utils/database/ticketPanelOp.js';
import {
  saveTicketData,
  getOpenTicketCountForUser,
  incrementTicketCounter,
} from '../utils/database.js';
import { logTicketEvent } from '../utils/ticket/ticketLogging.js';
import { logger } from '../utils/logger.js';
import { InteractionHelper } from '../utils/interactionHelper.js';
import { checkRateLimit } from '../utils/rateLimiter.js';
import { replyUserError, ErrorTypes, handleInteractionError, createError } from '../utils/errorHandler.js';

const MODAL_PREFIX = 'ticketpanelop_modal';
const RATE_LIMIT_MAX = 3;
const RATE_LIMIT_WINDOW_MS = 60000;

function slugify(name) {
  return String(name || 'ticket')
    .toLowerCase()
    .replace(/[^a-z0-9]+/g, '-')
    .replace(/^-+|-+$/g, '')
    .slice(0, 40) || 'ticket';
}

function buildControlRow({ claimedBy = null } = {}) {
  return new ActionRowBuilder().addComponents(
    new ButtonBuilder()
      .setCustomId('ticket_claim')
      .setLabel(claimedBy ? 'Claimed' : 'Claim')
      .setStyle(claimedBy ? ButtonStyle.Secondary : ButtonStyle.Primary)
      .setEmoji('🙋')
      .setDisabled(!!claimedBy),
    new ButtonBuilder()
      .setCustomId('ticket_pin')
      .setLabel('Pin')
      .setStyle(ButtonStyle.Secondary)
      .setEmoji('📌'),
    new ButtonBuilder()
      .setCustomId('ticket_close')
      .setLabel('Close')
      .setStyle(ButtonStyle.Danger)
      .setEmoji('🔒'),
  );
}

async function resolvePanelType(interaction, messageId, typeIndex) {
  const guildId = interaction.guildId;
  const panel = await getTicketPanelOpData(guildId, messageId);

  if (!panel) {
    throw createError(
      'Ticket panel data missing',
      ErrorTypes.CONFIGURATION,
      'This ticket panel is no longer configured. Please ask an admin to set it up again with `/ticketpanelop setup`.',
      { guildId, messageId },
    );
  }

  const index = Number(typeIndex);
  const type = Array.isArray(panel.types) ? panel.types[index] : null;

  if (!type) {
    throw createError(
      'Ticket panel type missing',
      ErrorTypes.VALIDATION,
      'That ticket type no longer exists on this panel.',
      { guildId, messageId, typeIndex },
    );
  }

  return { panel, type };
}

const ticketPanelOpSelectHandler = {
  name: 'ticketpanelop_select',
  async execute(interaction, client) {
    try {
      if (!interaction.inGuild()) {
        return await replyUserError(interaction, { type: ErrorTypes.UNKNOWN, message: 'This action can only be used in a server.' });
      }

      const typeIndex = interaction.values?.[0];
      if (typeIndex === undefined) {
        return await replyUserError(interaction, { type: ErrorTypes.VALIDATION, message: 'No ticket type was selected.' });
      }

      const { panel, type } = await resolvePanelType(interaction, interaction.message.id, typeIndex);

      const rateLimitKey = `${interaction.user.id}:ticketpanelop_create`;
      const allowed = await checkRateLimit(rateLimitKey, RATE_LIMIT_MAX, RATE_LIMIT_WINDOW_MS);
      if (!allowed) {
        return await replyUserError(interaction, { type: ErrorTypes.RATE_LIMIT, message: 'You are creating tickets too quickly. Please wait a minute and try again.' });
      }

      const config = await getGuildConfig(client, interaction.guildId);
      const maxTicketsPerUser = config.maxTicketsPerUser || 3;
      const currentTicketCount = await getOpenTicketCountForUser(interaction.guildId, interaction.user.id);

      if (currentTicketCount >= maxTicketsPerUser) {
        return await replyUserError(interaction, { type: ErrorTypes.UNKNOWN, message: `You have reached the maximum number of open tickets (${maxTicketsPerUser}).\n\nPlease close your existing tickets before creating a new one.\n\n**Current Tickets:** ${currentTicketCount}/${maxTicketsPerUser}` });
      }

      const modal = new ModalBuilder()
        .setCustomId(`${MODAL_PREFIX}:${interaction.message.id}:${typeIndex}`)
        .setTitle(String(type.name).slice(0, 45) || 'Create a Ticket');

      const reasonInput = new TextInputBuilder()
        .setCustomId('reason')
        .setLabel('How can we help?')
        .setStyle(TextInputStyle.Paragraph)
        .setPlaceholder('Describe your issue or request...')
        .setRequired(true)
        .setMaxLength(1000);

      modal.addComponents(new ActionRowBuilder().addComponents(reasonInput));

      await interaction.showModal(modal);
    } catch (error) {
      logger.error('Error opening ticketpanelop modal:', error);
      if (!interaction.replied && !interaction.deferred) {
        await handleInteractionError(interaction, error, { type: 'select_menu', handler: 'ticketpanelop' });
      }
    }
  },
};

const ticketPanelOpModalHandler = {
  name: MODAL_PREFIX,
  async execute(interaction, client, args) {
    try {
      if (!interaction.inGuild()) {
        return await replyUserError(interaction, { type: ErrorTypes.UNKNOWN, message: 'This action can only be used in a server.' });
      }

      const deferred = await InteractionHelper.safeDefer(interaction, { flags: MessageFlags.Ephemeral });
      if (!deferred) return;

      const [messageId, typeIndex] = args;
      const { panel, type } = await resolvePanelType(interaction, messageId, typeIndex);

      const reason = interaction.fields.getTextInputValue('reason')?.trim() || 'No reason provided.';
      const guild = interaction.guild;
      const member = interaction.member;

      let category = panel.categoryId ? guild.channels.cache.get(panel.categoryId) : null;
      if (panel.categoryId && !category) {
        category = await guild.channels.fetch(panel.categoryId).catch(() => null);
      }
      if (!category) {
        category = guild.channels.cache.find(
          (c) => c.type === ChannelType.GuildCategory && c.name.toLowerCase().includes('ticket'),
        );
      }
      if (!category) {
        category = await guild.channels.create({
          name: 'Tickets',
          type: ChannelType.GuildCategory,
          permissionOverwrites: [{ id: guild.id, deny: [PermissionFlagsBits.ViewChannel] }],
        });
      }

      const ticketNumber = await incrementTicketCounter(guild.id);
      const channelName = `${slugify(type.name)}-${ticketNumber}`;

      const permissionOverwrites = [
        { id: guild.id, deny: [PermissionFlagsBits.ViewChannel] },
        {
          id: member.id,
          allow: [
            PermissionFlagsBits.ViewChannel,
            PermissionFlagsBits.SendMessages,
            PermissionFlagsBits.AttachFiles,
            PermissionFlagsBits.ReadMessageHistory,
          ],
        },
      ];

      if (type.roleId) {
        permissionOverwrites.push({
          id: type.roleId,
          allow: [
            PermissionFlagsBits.ViewChannel,
            PermissionFlagsBits.SendMessages,
            PermissionFlagsBits.AttachFiles,
            PermissionFlagsBits.ReadMessageHistory,
          ],
        });
      }

      const channel = await guild.channels.create({
        name: channelName,
        type: ChannelType.GuildText,
        parent: category?.id,
        permissionOverwrites,
      });

      const ticketData = {
        id: channel.id,
        userId: member.id,
        guildId: guild.id,
        createdAt: new Date().toISOString(),
        status: 'open',
        claimedBy: null,
        priority: 'none',
        reason,
        ticketType: type.name,
        staffRoleId: type.roleId || null,
        panelMessageId: panel.messageId,
      };

      await saveTicketData(guild.id, channel.id, ticketData);

      const embed = createEmbed({
        title: `Ticket #${ticketNumber}`,
        description: `${member.toString()}, thanks for reaching out!\n\n**Type:** ${type.name}\n**Reason:** ${reason}`,
        color: 'info',
        fields: [
          { name: 'Status', value: '🟢 Open', inline: true },
          { name: 'Support Role', value: type.roleId ? `<@&${type.roleId}>` : 'Not set', inline: true },
          { name: 'Claimed By', value: 'Not claimed', inline: true },
          { name: 'Created', value: `<t:${Math.floor(Date.now() / 1000)}:R>`, inline: true },
        ],
      });

      const staffMention = type.roleId ? ` <@&${type.roleId}>` : '';
      const ticketMessage = await channel.send({
        content: `${member.toString()}${staffMention}`,
        embeds: [embed],
        components: [buildControlRow()],
      });

      await ticketMessage.pin().catch(() => {});

      await logTicketEvent({
        client: guild.client,
        guildId: guild.id,
        event: {
          type: 'open',
          ticketId: channel.id,
          ticketNumber,
          userId: member.id,
          executorId: member.id,
          reason,
          priority: 'none',
          metadata: {
            channelId: channel.id,
            categoryName: category?.name || 'Default',
            ticketType: type.name,
            source: 'ticketpanelop',
          },
        },
      });

      await InteractionHelper.safeEditReply(interaction, {
        embeds: [successEmbed('Ticket Created', `Your **${type.name}** ticket has been created in ${channel}!`)],
      });

      logger.info('Ticket created via /ticketpanelop', {
        userId: member.id,
        guildId: guild.id,
        channelId: channel.id,
        ticketType: type.name,
      });
    } catch (error) {
      logger.error('Error creating ticket from ticketpanelop modal:', error);
      await handleInteractionError(interaction, error, { type: 'modal', handler: 'ticketpanelop' });
    }
  },
};

export { ticketPanelOpSelectHandler, ticketPanelOpModalHandler };
