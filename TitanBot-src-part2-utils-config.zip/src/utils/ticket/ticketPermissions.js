// ticketPermissions.js

import { PermissionFlagsBits } from 'discord.js';
import { getGuildConfig } from '../../services/config/guildConfig.js';
import { getTicketData } from '../database.js';

export async function getTicketPermissionContext({ client, interaction }) {
  const guildId = interaction.guildId;
  const channelId = interaction.channelId;

  const [config, ticketData] = await Promise.all([
    getGuildConfig(client, guildId),
    getTicketData(guildId, channelId)
  ]);

  const hasManageChannels = interaction.member.permissions.has(PermissionFlagsBits.ManageChannels);
  const staffRoleId = config.ticketStaffRoleId || null;
  const hasTicketStaffRole = Boolean(staffRoleId && interaction.member.roles?.cache?.has(staffRoleId));
  const isTicketCreator = Boolean(
    ticketData?.userId && String(ticketData.userId) === String(interaction.user.id),
  );

  // Tickets created via /ticketpanelop carry their own per-type support role
  // (ticketData.staffRoleId). Regular tickets never set this field, so this
  // has no effect on the existing global-staff-role behavior.
  const panelStaffRoleId = ticketData?.staffRoleId || null;
  const hasPanelStaffRole = Boolean(
    panelStaffRoleId && interaction.member.roles?.cache?.has(panelStaffRoleId),
  );

  return {
    config,
    ticketData,
    hasManageChannels,
    hasTicketStaffRole,
    hasPanelStaffRole,
    isTicketCreator,
    canManageTicket: hasManageChannels || hasTicketStaffRole || hasPanelStaffRole,
    canCloseTicket: hasManageChannels || hasTicketStaffRole || hasPanelStaffRole || isTicketCreator,
  };
}