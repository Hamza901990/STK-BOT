// ticketPanelOp.js — storage for /ticketpanelop dropdown panels.
// Self-contained: does not touch the existing single-panel /ticket setup data.

import { db, getFromDb } from './wrapper.js';
import { getTicketPanelOpKey, getTicketPanelOpPrefix } from './keys.js';

export { getTicketPanelOpKey, getTicketPanelOpPrefix } from './keys.js';

export async function getTicketPanelOpData(guildId, messageId) {
    if (!db.initialized) {
        await db.initialize();
    }

    const key = getTicketPanelOpKey(guildId, messageId);
    return await db.get(key);
}

export async function saveTicketPanelOpData(guildId, messageId, data) {
    if (!db.initialized) {
        await db.initialize();
    }

    const key = getTicketPanelOpKey(guildId, messageId);
    await db.set(key, data);
}

export async function deleteTicketPanelOpData(guildId, messageId) {
    if (!db.initialized) {
        await db.initialize();
    }

    const key = getTicketPanelOpKey(guildId, messageId);
    await db.delete(key);
}

export async function listTicketPanelOpPanels(guildId) {
    if (!db.initialized) {
        await db.initialize();
    }

    if (typeof db.list !== 'function') {
        return [];
    }

    const prefix = getTicketPanelOpPrefix(guildId);
    const keys = await db.list(prefix);
    const panels = [];

    for (const key of keys) {
        const panel = await getFromDb(key, null);
        if (panel) panels.push(panel);
    }

    return panels;
}
