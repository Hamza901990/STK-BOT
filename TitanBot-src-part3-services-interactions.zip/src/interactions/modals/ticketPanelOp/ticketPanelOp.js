import { ticketPanelOpModalHandler } from '../../../handlers/ticketPanelOpHandlers.js';

export default ticketPanelOpModalHandler;
