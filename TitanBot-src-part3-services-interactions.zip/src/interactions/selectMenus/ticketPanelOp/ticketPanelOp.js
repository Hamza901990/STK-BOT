import { ticketPanelOpSelectHandler } from '../../../handlers/ticketPanelOpHandlers.js';

export default ticketPanelOpSelectHandler;
